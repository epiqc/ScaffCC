var searchData=
[
  ['enhancing_20functionality',['Enhancing Functionality',['../enhance_core.html',1,'']]]
];
