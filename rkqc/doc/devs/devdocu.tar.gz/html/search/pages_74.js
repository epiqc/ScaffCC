var searchData=
[
  ['tutorial_3a_20window_20optimization',['Tutorial: Window Optimization',['../page_tutorial_window_optimization.html',1,'']]]
];
